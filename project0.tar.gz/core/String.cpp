// String.cpp
//
// ICS 46 Winter 2022
// Project #0: Getting to Know the ICS 46 VM
//
// Implement all of your String member functions in this file.
//
// Note that the entire standard library -- both the C Standard
// Library and the C++ Standard Library -- is off-limits for this
// task, as the goal is to exercise your low-level implementation
// skills (pointers, memory management, and so on).

#include "String.hpp"
#include "OutOfBoundsException.hpp"

String::String()
      :len{0}
{
    ch = new char[1];
    ch[0] = '\0';
}

String::String(const char* chars)
{
    int count = 0;
    while(chars[count]!='\0')
    {
        count++;
        
    }
    len = count;
    ch = new char[count+1];
    for(int i=0; i<count;i++){
        ch[i] = chars[i];
    }
    ch[count] = '\0';
    
}

String::String(const String& s)
      :len{0}
{
    len+= s.length();
    ch = new char[len+1];
    for(int i=0; i<len;i++){
        ch[i] = s.toChars()[i];
    }
    ch[len] = '\0';
}

String::~String() noexcept{
    delete []ch;
}

String& String::operator=(const String& s){
    if(this != &s){
        len = s.length();
        delete []ch;
        ch = new char[len+1];
        for(int i=0; i<len;i++){
            ch[i] = s.toChars()[i];
        }
        ch[len] = '\0';
    }
    return *this;
}

void String::append(const String& s){
    char* tempChar = new char[len+s.length()+1];
    for(int i = 0; i< len; i++){
        tempChar[i] = ch[i];
    }
    for(int j = 0; j< s.length(); j++){
        tempChar[j+len] = s.toChars()[j];
    }
    tempChar[len+s.length()] = '\0';
    delete []ch;
    ch = tempChar;
    len += s.length();
}

char String::at(unsigned int index) const{
    if(index>=len){
        throw OutOfBoundsException();
    }
    return ch[index];
}

char& String::at(unsigned int index){
    if(index>=len){
        throw OutOfBoundsException();
    }
    return ch[index];
}

void String::clear(){
    len = 0;
    delete []ch;
    ch = new char[1];
    ch[0] = '\0';
}

int String::compareTo(const String& s) const noexcept{
    for(int i=0; i<len; i++){
        if(ch[i]-s.toChars()[i] >0){
            return 1;
        }
        else if (ch[i] - s.toChars()[i]<0){
            return -1;
        }
    }
    if(len == s.length()){
        return 0;
    }
    else if(len>s.length()){
        return 1;
    }
    else{
        return -1;
    }
    
}

String String::concatenate(const String& s) const{
    int finalLen = s.length()+len;
    char* tempChar = new char[finalLen+1];
    for(int i=0; i<len;i++){
        tempChar[i] = ch[i];
    }
    for(int j=0; j<s.length();j++){
        tempChar[j+len] = s.toChars()[j];
    }
    tempChar[finalLen] = '\0';
    String finalstr(tempChar);
    delete []tempChar;
    return finalstr;
    
}

bool String::contains(const String& substring) const noexcept{
    for(int i=0; i<len;i++){
        if(ch[i] == substring.toChars()[0]){
            int count = 0;
            for(int j=0; j<substring.length();j++){
                if(j+i>len){
                    return false;
                }
                else if (ch[i+j] == substring.toChars()[j]){
                    count ++;
                }
            }
            if(count == substring.length()){
                return true;
            }
        }
    }
    return false;
}

bool String::equals(const String& s) const noexcept{
    if(len != s.length()){
        return false;
    }
    for(int i=0; i<len; i++){
        if(ch[i]-s.toChars()[i] >0){
            return false;
        }
        else if (ch[i] - s.toChars()[i]<0){
            return false;
        }
    }
    return true;
}

int String::find(const String& substring) const noexcept{
    for(int i=0; i<len;i++){
        if(ch[i] == substring.toChars()[0]){
            int count = 0;
            for(int j=0; j<substring.length();j++){
                if(j+i>len){
                    return -1;
                }
                else if (ch[i+j] == substring.toChars()[j]){
                    count ++;
                }
            }
            if(count == substring.length()){
                return i;
            }
        }
    }
    return -1;
}

bool String::isEmpty() const noexcept{
    if(len == 0){
        return true;
    }
    else{
        return false;
    }
}



unsigned int String::length() const noexcept{
    return len;
}

String String::substring(unsigned int startIndex, unsigned int endIndex) const{
    if(startIndex>=len || endIndex > len){
        throw OutOfBoundsException();
    }
    char* temp = new char[endIndex-startIndex+1];
    for(int k =0; k<endIndex-startIndex; k++){
        temp[k] = ch[k+startIndex];
    }
    temp[endIndex-startIndex] = '\0';
    String final(temp);
    delete [] temp;
    return final;
}

const char* String::toChars() const noexcept{
    return ch;
}
